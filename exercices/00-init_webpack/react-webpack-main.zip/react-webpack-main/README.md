# react-webpack
A simple react starter template with Webpack and Babel configuration. An alternative to using create-react-app (CRA) for your next react app.
Link for follow along [blog](https://dev.to/riyanegi/setting-up-webpack-5-with-react-and-babel-from-scratch-2021-271l) to understand webpack and babel configuration and how to build this react starter template by yourself. 
